package com.excel.exception;

public class EmployeeExistenceException extends RuntimeException {

	public EmployeeExistenceException(String message) {
		super(message);
	}
}
